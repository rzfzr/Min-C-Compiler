#include<iostream>
using namespace std;
int main(){
int x;
void oi(string z)
{
int y;
y=10;
cout<<y;
 return 0;
}
cin>>x;
cout<<x;
 return 0;
}

